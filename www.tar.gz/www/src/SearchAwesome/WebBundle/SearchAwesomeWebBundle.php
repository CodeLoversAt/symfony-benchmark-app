<?php

namespace SearchAwesome\WebBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SearchAwesomeWebBundle extends Bundle
{
}
