<?php
/**
 * @package font-awesome-searcher
 *
 * @author Daniel Holzmann <d@velopment.at>
 * @date 05.07.14
 * @time 19:12
 */

namespace SearchAwesome\CoreBundle\Repository;


use Doctrine\ODM\MongoDB\DocumentRepository;

class UserRepository extends DocumentRepository
{
} 