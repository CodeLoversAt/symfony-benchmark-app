<?php

namespace SearchAwesome\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SearchAwesomeCoreBundle extends Bundle
{
}
