<?php

namespace SearchAwesome\ApiBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SearchAwesomeApiBundle extends Bundle
{
}
